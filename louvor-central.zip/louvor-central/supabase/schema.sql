-- Louvor Central: execute no SQL Editor de um projeto Supabase exclusivo.
-- Sem login: leitores e editores são anônimos. QUALQUER pessoa com as credenciais
-- públicas do site poderá alterar dados. Não guarde dados pessoais sensíveis.
create extension if not exists pgcrypto;

create table if not exists public.members (
 id uuid primary key default gen_random_uuid(),
 name text not null check (char_length(trim(name)) between 1 and 120),
 role text not null default 'Vocal' check(char_length(role) <= 80),
 phone text default '' check(char_length(phone) <= 40),
 active boolean not null default true,
 created_at timestamptz not null default now()
);
create table if not exists public.songs (
 id uuid primary key default gen_random_uuid(),
 title text not null check(char_length(trim(title)) between 1 and 180),
 artist text not null default '' check(char_length(artist) <= 140),
 song_key text not null default '' check(char_length(song_key) <= 24),
 bpm integer check(bpm between 20 and 300),
 youtube_url text not null default '' check(char_length(youtube_url) <= 1200),
 chords_url text not null default '' check(char_length(chords_url) <= 1200),
 notes text not null default '' check(char_length(notes) <= 4000),
 created_at timestamptz not null default now()
);
create table if not exists public.services (
 id uuid primary key default gen_random_uuid(),
 title text not null check(char_length(trim(title)) between 1 and 160),
 service_date date not null,
 service_time time not null default '19:00',
 location text not null default '' check(char_length(location) <= 180),
 notes text not null default '' check(char_length(notes) <= 4000),
 created_at timestamptz not null default now()
);
create table if not exists public.service_members (
 service_id uuid not null references public.services(id) on delete cascade,
 member_id uuid not null references public.members(id) on delete cascade,
 function_name text not null default '' check(char_length(function_name) <= 100),
 primary key(service_id, member_id)
);
create table if not exists public.service_songs (
 id uuid primary key default gen_random_uuid(),
 service_id uuid not null references public.services(id) on delete cascade,
 song_id uuid not null references public.songs(id) on delete cascade,
 position integer not null default 0,
 chosen_key text not null default '' check(char_length(chosen_key) <= 24),
 notes text not null default '' check(char_length(notes) <= 2000),
 unique(service_id, song_id)
);
create index if not exists idx_services_date on public.services(service_date);
create index if not exists idx_service_songs_order on public.service_songs(service_id, position);

alter table public.members enable row level security;
alter table public.songs enable row level security;
alter table public.services enable row level security;
alter table public.service_members enable row level security;
alter table public.service_songs enable row level security;

grant usage on schema public to anon;
grant select, insert, update, delete on public.members, public.songs, public.services, public.service_members, public.service_songs to anon;

-- É uma opção deliberadamente ABERTA (sem autenticação).
-- Para dados privados, substitua por autenticação e regras específicas.
do $$ declare t text; begin
 foreach t in array array['members','songs','services','service_members','service_songs'] loop
  execute format('drop policy if exists "open_read" on public.%I', t);
  execute format('drop policy if exists "open_insert" on public.%I', t);
  execute format('drop policy if exists "open_update" on public.%I', t);
  execute format('drop policy if exists "open_delete" on public.%I', t);
  execute format('create policy "open_read" on public.%I for select to anon using (true)', t);
  execute format('create policy "open_insert" on public.%I for insert to anon with check (true)', t);
  execute format('create policy "open_update" on public.%I for update to anon using (true) with check (true)', t);
  execute format('create policy "open_delete" on public.%I for delete to anon using (true)', t);
 end loop;
end $$;

-- Ativar Realtime (idempotente)
do $$ declare t text; begin
 foreach t in array array['members','songs','services','service_members','service_songs'] loop
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename=t) then
   execute format('alter publication supabase_realtime add table public.%I',t);
  end if;
 end loop;
end $$;
