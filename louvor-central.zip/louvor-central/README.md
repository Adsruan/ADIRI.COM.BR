# Louvor Central — versão 1.0

Sistema web responsivo para gerenciar repertório, integrantes, cultos, escalas e sequência musical, com banco de dados compartilhado no Supabase. Implementado com **HTML, CSS e JavaScript (Vite)**, pronto para GitHub/Vercel.

## Recursos

- Painel com próximo culto e resumo do ministério.
- Cadastro, edição, exclusão e busca de músicas (tom, BPM, links YouTube/cifra e observações).
- Cadastro, edição, exclusão e busca de integrantes.
- Criação e edição de cultos com data, horário, local e avisos.
- Seleção de músicos para cada culto e funções específicas.
- Seleção das músicas em ordem, com tom específico para cada culto e observações.
- Reordenação, remoção, impressão do planejamento.
- Banco online único, Realtime e sincronização no retorno da aba ao primeiro plano.
- Sem login, com acesso de leitura/escrita pública (ver **Aviso de segurança** abaixo).

## Configuração do Supabase

1. Crie um projeto em https://supabase.com/dashboard.
2. Em **SQL Editor**, execute o conteúdo completo de `supabase/schema.sql`.
3. Em **Project Settings > API Keys**, copie a **publishable key** (`sb_publishable_...`) ou, em projetos legados, a chave `anon`. **Nunca use `service_role` ou secret key** no frontend.
4. Em **Project Settings**, copie a URL do projeto (`https://...supabase.co`).
5. Crie o arquivo `.env` com base em `.env.example` e preencha as duas variáveis.

## Rodar no Mac / PC

Tenha Node.js instalado. Dentro da pasta do projeto:

```bash
npm install
npm run dev
```

Abra a URL indicada no terminal (normalmente http://localhost:5173).

## Publicar no GitHub + Vercel

1. Envie **a pasta inteira** para um repositório do GitHub (não envie o arquivo `.env`).
2. Em https://vercel.com, clique em **Add New > Project** e importe o repositório.
3. Framework: **Vite**. Build Command: `npm run build`. Output Directory: `dist`.
4. Em **Environment Variables**, adicione:
   - `VITE_SUPABASE_URL` = URL do projeto
   - `VITE_SUPABASE_PUBLISHABLE_KEY` = chave publicável do projeto
5. Faça o deploy. Todos os aparelhos devem abrir **a mesma URL do Vercel**.

Os dados NÃO ficam no GitHub ou no Vercel: são armazenados em tabelas PostgreSQL do Supabase e compartilhados por todos os navegadores que usam as mesmas variáveis.

## Aviso importante sobre segurança

**Como foi solicitado que não haja login**, as regras incluídas no SQL permitem leitura, criação, alteração e exclusão para o papel `anon`. Isso significa que **o sistema não é privado apenas por o link ser pouco divulgado**: qualquer pessoa que tiver a URL, as credenciais públicas do frontend ou souber consultar a API pode ler e alterar os registros, mesmo sem interface. Não coloque contatos pessoais, dados sensíveis ou informações confidenciais no sistema.

Para uso além de um pequeno piloto, recomenda-se implementar Supabase Auth (por exemplo, login por link mágico) e políticas RLS específicas por pessoa ou grupo. Outra alternativa é uma camada de autorização no servidor com permissões verificadas; apenas esconder botões ou colocar um PIN no JavaScript não protege o banco.

## Limitações da versão 1.0

- Ainda não inclui histórico de alterações, auditoria, notificações, integração com WhatsApp, anexos de áudio, permissões ou prevenção de conflitos em edição simultânea.
- Realtime normalmente avisa outras abas rapidamente, mas depende de conectividade e configuração do serviço; o aplicativo atualiza os dados também ao recuperar foco.
- Alguns provedores podem exigir configuração de concessões para a Data API do Supabase; o SQL inclui `GRANT` e políticas RLS nas cinco tabelas.
- Links externos podem apontar para terceiros; confira antes de clicar.
